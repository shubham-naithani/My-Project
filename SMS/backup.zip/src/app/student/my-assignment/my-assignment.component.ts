import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-assignment',
  templateUrl: './my-assignment.component.html',
  styleUrls: ['./my-assignment.component.css']
})
export class MyAssignmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
