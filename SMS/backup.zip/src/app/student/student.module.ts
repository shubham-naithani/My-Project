import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';
import { ProfileComponent } from './profile/profile.component';
import { SubjectsComponent } from './subjects/subjects.component';
import { UpcomingEventsComponent } from './upcoming-events/upcoming-events.component';
import { SidebarComponent } from './shared/sidebar/sidebar.component';
import { HeaderComponent } from './shared/header/header.component';
import { FooterComponent } from './shared/footer/footer.component';
import { ResultComponent } from './result/result.component';
import { MyAssignmentComponent } from './my-assignment/my-assignment.component';
import {StudentRoutingModule} from './student.routing.module';
import {MaterialModule} from '../material/material.module';
import { ReactiveFormsModule } from '@angular/forms';
import { AdmissionFormComponent } from './admission-form/admission-form.component';
import { ProgresSbarComponent } from '../auth/shared/progres-sbar/progres-sbar.component';




@NgModule({
  declarations: [
    DashboardComponent,
    HomeComponent,
    ProfileComponent,
    SubjectsComponent,
    UpcomingEventsComponent,
    SidebarComponent,
    HeaderComponent,
    FooterComponent,
    ResultComponent,
    MyAssignmentComponent,
    AdmissionFormComponent
  ],
  imports: [
    CommonModule,
    StudentRoutingModule ,
    MaterialModule,
    ReactiveFormsModule,
    ProgresSbarComponent
  ]
})
export class StudentModule { }
