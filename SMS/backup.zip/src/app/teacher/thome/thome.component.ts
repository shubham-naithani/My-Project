import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thome',
  templateUrl: './thome.component.html',
  styleUrls: ['./thome.component.css']
})
export class ThomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
