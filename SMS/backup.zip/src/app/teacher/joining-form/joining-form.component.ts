import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { TeacherService } from '../teacher.service';

@Component({
  selector: 'app-joining-form',
  templateUrl: './joining-form.component.html',
  styleUrls: ['./joining-form.component.css']
})
export class JoiningFormComponent implements OnInit {
  joiningform:FormGroup;

  constructor(private fb: FormBuilder, private toast: ToastrService,private service:TeacherService,private route:Router) { }

  ngOnInit(){
    this.joiningform = new FormGroup({
      F_Name: new FormControl(""),
      L_Name: new FormControl(""),
      D_O_B: new FormControl(""),
      Age: new FormControl(""),
      Gender: new FormControl(""),
      Cast: new FormControl(""),
      Religion: new FormControl(""),
      E_Mail: new FormControl(""),
      Contact_No: new FormControl(""),
      ADDRESS: new FormControl(""),
      Nationality: new FormControl(""),
      Maritial_Status: new FormControl(""),
      Qualification: new FormControl(""),
      Classes_You_Can_Teach: new FormControl(""),
      Subjects_You_Can_Teach: new FormControl(""),
      Experience_Of_Teaching: new FormControl(""),

    })
  }

  getErrorMessage() {
    if (this.joiningform.controls.E_Mail.hasError('required')) {
      return 'You must enter a value';
    }
    return this.joiningform.controls.E_Mail.hasError('E_Mail') ? 'Not a valid email' : '';
  }

  submit(){
    debugger
    let data = this.joiningform.value;
    this.service.Joiningform(data).subscribe((res: any) => {
      if (res.statusCode == 200) {
        this.toast.success(res.message);
      } else {
        this.toast.error(res.message);
      }
    })
  }

}
