import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tprofile',
  templateUrl: './tprofile.component.html',
  styleUrls: ['./tprofile.component.css']
})
export class TprofileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
