import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tsidebar',
  templateUrl: './tsidebar.component.html',
  styleUrls: ['./tsidebar.component.css']
})
export class TsidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
