import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theader',
  templateUrl: './theader.component.html',
  styleUrls: ['./theader.component.css']
})
export class TheaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
