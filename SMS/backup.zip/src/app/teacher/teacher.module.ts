import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TeacherDashboardComponent } from './teacher-dashboard/teacher-dashboard.component';
import { TheaderComponent } from './shared/theader/theader.component';
import { TfooterComponent } from './shared/tfooter/tfooter.component';
import { TsidebarComponent } from './shared/tsidebar/tsidebar.component';
import { ThomeComponent } from './thome/thome.component';
import { TeacherRoutingModule } from './teacher.routing.module';
import { ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../material/material.module';
import { TprofileComponent } from './tprofile/tprofile.component';
import { BrowserModule } from '@angular/platform-browser';
import { TimeTableComponent } from './time-table/time-table.component';
import { JoiningFormComponent } from './joining-form/joining-form.component';
import { ProgresSbarComponent } from '../auth/shared/progres-sbar/progres-sbar.component';



@NgModule({
  declarations: [
    ThomeComponent,
    TprofileComponent,
    TeacherDashboardComponent,
    TheaderComponent,
    TfooterComponent,
    TsidebarComponent,
    TimeTableComponent,
    JoiningFormComponent

  ],
  imports: [
    CommonModule,
    MaterialModule,
    ReactiveFormsModule,
    TeacherRoutingModule,
    ProgresSbarComponent
  ]
})
export class TeacherModule { }
