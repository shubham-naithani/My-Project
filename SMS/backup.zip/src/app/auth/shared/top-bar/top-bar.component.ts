import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router'
@Component({
  selector: 'app-top-bar',
  templateUrl: './top-bar.component.html',
  styleUrls: ['./top-bar.component.css']
})
export class TopBarComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  login(){
    this.router.navigateByUrl("/Login")
  }

  register(){
    this.router.navigateByUrl("/Registeration")
  }
  settings(){
    this.router.navigateByUrl("/")
  }
  
}
