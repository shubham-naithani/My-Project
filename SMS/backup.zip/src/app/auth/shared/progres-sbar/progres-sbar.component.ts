import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-progres-sbar',
  templateUrl: './progres-sbar.component.html',
  styleUrls: ['./progres-sbar.component.css']
})
export class ProgresSbarComponent implements OnInit {
   

  constructor() { }

  ngOnInit(){
  }

}
