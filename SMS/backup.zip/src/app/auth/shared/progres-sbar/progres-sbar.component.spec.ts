import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProgresSbarComponent } from './progres-sbar.component';

describe('ProgresSbarComponent', () => {
  let component: ProgresSbarComponent;
  let fixture: ComponentFixture<ProgresSbarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProgresSbarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProgresSbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
