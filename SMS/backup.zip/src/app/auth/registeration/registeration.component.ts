import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-registeration',
  templateUrl: './registeration.component.html',
  styleUrls: ['./registeration.component.css']
})
export class RegisterationComponent implements OnInit {
  registerform: FormGroup;
  hide: boolean;
  spinner:boolean=false;

  constructor(private fb: FormBuilder, private service: AuthService, private route: Router, private toast: ToastrService,private router:Router) { }

  ngOnInit(){
    this.registerform = this.fb.group({
      F_Name: [""],
      L_Name: [""],
      E_Mail: [""],
      Password: [''],
      D_O_B: [""],
      Contact_No: [""],
      Role:[""]
    })
  }
  getErrorMessage() {
    if (this.registerform.controls.E_Mail.hasError('required')) {
      return 'You must enter a value';
    }
    return this.registerform.controls.E_Mail.hasError('email') ? 'Not a valid email' : '';
  }
  submit() {
    this.spinner=true;
    let data = this.registerform.value;
    this.service.registeration(data).subscribe((res: any) => {
      if(res.statusCode==200){
        this.toast.success(res.message);
        this.router.navigateByUrl("/VerifyOTP");
       }else{
        this.toast.error(res.message);
       }
       this.spinner=false;
     })
  }
}