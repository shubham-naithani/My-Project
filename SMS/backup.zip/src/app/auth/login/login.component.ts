import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginform: FormGroup;
  successmessage: any;
  hide: boolean;
  spinner:boolean=false;

  constructor(private fb: FormBuilder, private authService: AuthService, private toat: ToastrService, private route: Router) { }

  ngOnInit() {
    this.loginform = new FormGroup({
      E_Mail: new FormControl(''),
      Password: new FormControl(''),
    })
  }

  getErrorMessage() {
    if (this.loginform.controls.E_Mail.hasError('required')) {
      return 'You must enter a value';
    }
    return this.loginform.controls.E_Mail.hasError('email') ? 'Not a valid email' : '';

  }
  get formcontrol() { return this.loginform.controls }
  submit() {
    this.spinner=true;
    debugger
    if (this.loginform.valid) {
      let data = {
        E_Mail: this.loginform.value.E_Mail,
        Password: this.loginform.value.Password
      }
      this.authService.login(data).subscribe((res: any) => {
        debugger
        if (res.statusCode == 200) {
          this.toat.success(res.message);
          localStorage.setItem("token", res.token);
          if (res.responseData === "student") {
            this.route.navigateByUrl("/student");
            this.toat.success(res.message);

          } else if (res.responseData === "teacher") {
            this.route.navigateByUrl("/teacher");
            this.toat.success(res.message);
          }
          else if (res.responseData === "admin") {
            this.route.navigateByUrl("/admin");
            this.toat.success(res.message);
          }
        } else {
          this.toat.error(res.message);
        }
        this.spinner=false;
      });
    }
  }
};