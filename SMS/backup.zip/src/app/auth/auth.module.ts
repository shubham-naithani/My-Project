import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthRoutingModule } from './auth-routing.module';
import { HomeComponent } from './home/home.component';
import { TopBarComponent } from './shared/top-bar/top-bar.component';
import { SidebarComponent } from './shared/sidebar/sidebar.component';
import { MaterialModule } from '../material/material.module';
import { MainComponent } from './main/main.component';
import { VerifyOtpComponent } from './verify-otp/verify-otp.component';
import { ResendOtpComponent } from './resend-otp/resend-otp.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { ReactiveFormsModule } from '@angular/forms';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { RegisterationComponent } from './registeration/registeration.component';
import { LoginComponent } from './login/login.component';
import { ProgresSbarComponent } from './shared/progres-sbar/progres-sbar.component';



@NgModule({
  declarations: [
    HomeComponent,
    TopBarComponent,
    SidebarComponent,
    MainComponent,
    VerifyOtpComponent,
    ResendOtpComponent,
    ForgetPasswordComponent,
    ResetPasswordComponent,
    RegisterationComponent,
    LoginComponent,
    ProgresSbarComponent
  ],
  imports: [
    CommonModule,
    AuthRoutingModule,
    MaterialModule,
    ReactiveFormsModule
  ]
})
export class AuthModule { }
