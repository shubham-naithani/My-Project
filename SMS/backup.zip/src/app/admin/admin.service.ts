import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {  Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  baseURL:"http://localhost:65468/adminAdmin/";

  constructor(private http:HttpClient) { }

  getPendingFormRequests():Observable<any>{debugger
    let url = 'http://localhost:65468/adminAdmin/'
    return this.http.get<any>(url + "get_pending_form_requests");
  }

  getDeleteRequest():Observable<any>{
    let url = 'http://localhost:65468/adminAdmin/'
    return this.http.get<any>(url + "get_delete_requests")
  }

  deleteJoiningForm() {debugger
    let url = 'http://localhost:65468/adminAdmin/'
    return this.http.delete<any>(url + "delete-joining-form");
  }
}
