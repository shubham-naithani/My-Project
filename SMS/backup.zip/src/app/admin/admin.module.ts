import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { ClassComponent } from './class/class.component';
import { FeeStructureComponent } from './fee-structure/fee-structure.component';
import { ResultComponent } from './result/result.component';
import { StudentsComponent } from './students/students.component';
import { TeachersComponent } from './teachers/teachers.component';
import { SideBarComponent } from './shared/side-bar/side-bar.component';
import { HeaderComponent } from './shared/header/header.component';
import { FooterComponent } from './shared/footer/footer.component';
import {MaterialModule} from '../material/material.module'
import { ReactiveFormsModule } from '@angular/forms';
import {AdminRoutingModule} from '../admin/admin.routing.module'
import { ProgresSbarComponent } from '../auth/shared/progres-sbar/progres-sbar.component';



@NgModule({
  declarations: [
    AdminDashboardComponent,
    ClassComponent,
    FeeStructureComponent,
    ResultComponent,
    StudentsComponent,
    TeachersComponent,
    SideBarComponent,
    HeaderComponent,
    FooterComponent
  ],
  imports: [
    CommonModule,
    MaterialModule,
    ReactiveFormsModule,
    AdminRoutingModule,
    ProgresSbarComponent
  ]
})
export class AdminModule { }
