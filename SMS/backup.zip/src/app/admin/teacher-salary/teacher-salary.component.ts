import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teacher-salary',
  templateUrl: './teacher-salary.component.html',
  styleUrls: ['./teacher-salary.component.css']
})
export class TeacherSalaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
