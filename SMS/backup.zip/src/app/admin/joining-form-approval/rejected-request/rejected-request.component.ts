import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AdminService } from '../../admin.service';

export interface PeriodicElement {
  position: number;
  name: string;
  Email:string;
  Nationality:string;
  MaritialStatus:string;
  Qualification:string;
  SubjectsYouCanTeach:string;
  ExperienceOfTeaching:string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 0, 
    name: '',
    Email:'shubham@gmail.com',
    Nationality:'',
    MaritialStatus:'',
    Qualification:'',
    SubjectsYouCanTeach:'',
    ExperienceOfTeaching:''
  },
];

@Component({
  selector: 'app-rejected-request',
  templateUrl: './rejected-request.component.html',
  styleUrls: ['./rejected-request.component.css']
})
export class RejectedRequestComponent implements OnInit {
  data:any
  displayedColumns: string[] = [
    'position', 
    'name', 
    'Email', 
    'Nationality',
    'MaritialStatus',
    'Qualification',
    'SubjectsYouCanTeach',
    'ExperienceOfTeaching'
  ];
  dataSource = ELEMENT_DATA;

  constructor
  (
    private adminservice:AdminService,
    private snackBar:MatSnackBar,
  )
  {
     this.getDeleteRequests();
  }

  ngOnInit(): void {
  }

  getDeleteRequests(){
    this.adminservice.getDeleteRequest().subscribe((res:any) => {
      if (res.statusCode == 200) {
        this.snackBar.open(res.message)
      } else {
        this.snackBar.open(res.message)
      }
      console.log(res.responseData)
    })
  }

}
