import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DialogService } from 'src/app/shared/dialog.service';
import { AdminService } from '../../admin.service';

export interface PendingRequests {
  position: number;
  name: string;
  Email: string;
  Nationality: string;
  MaritialStatus: string;
  Qualification: string;
  SubjectsYouCanTeach: string;
  ExperienceOfTeaching: string;
  ClassesYouWillTeach: string;
  YourPeriods: string
  Approved: string
}let ELEMENT_DATA: PendingRequests[] = [
  {
    position: 0,
    name: '',
    Email: '',
    Nationality: '',
    MaritialStatus: '',
    Qualification: '',
    SubjectsYouCanTeach: '',
    ExperienceOfTeaching: '',
    ClassesYouWillTeach: '',
    YourPeriods: '',
    Approved: ''
  },
];

@Component({
  selector: 'app-pending-request',
  templateUrl: './pending-request.component.html',
  styleUrls: ['./pending-request.component.css']
})
export class PendingRequestComponent implements OnInit {
  data: any
  id: any;
  displayedColumns: string[] = [
    'position',
    'name',
    'Email',
    'Nationality',
    'MaritialStatus',
    'Qualification',
    'SubjectsYouCanTeach',
    'ExperienceOfTeaching',
    'ClassesYouWillTeach',
    'YourPeriods',
    'Approved'
  ];
  dataSource = ELEMENT_DATA;

  constructor
    (
      private adminservice: AdminService,
      private snackBar: MatSnackBar,
      private dialogService: DialogService
    ) {
    this.getPendingRequests()
  }

  ngOnInit(): void {
  }

  getPendingRequests() {
    this.adminservice.getPendingFormRequests().subscribe((res: any) => {
      if (res.statusCode == 200) {
        this.snackBar.open(res.message, 'undo', {
          duration: 3000
        })
        ELEMENT_DATA = res.responseData;
      } else {
        this.snackBar.open(res.message, 'undo', {
          duration: 3000
        })
      }
      this.dataSource = ELEMENT_DATA
    });
  }

  openApprovedDialog() {
    this.dialogService.openApprovedDialog()
  }


  deleteRequest() {

  }
}
